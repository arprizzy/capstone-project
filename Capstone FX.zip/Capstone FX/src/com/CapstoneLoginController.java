/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Esperis loreheart
 */
public class CapstoneLoginController implements Initializable {

    @FXML
    private Label lblMessage;
    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField txtPassword;
    
    
    @FXML
    private void btnLoginAct(ActionEvent event) throws Exception {
        if (txtUsername.getText().equals("test") && txtPassword.getText().equals("test")) {
           ((Node) (event.getSource())).getScene().getWindow().hide();
           Parent parent = FXMLLoader.load(getClass().getResource("/com/Main.fmxl"));    
           Stage stage = new Stage();
           Scene scene = new Scene(parent);
           stage.setScene(scene);
           stage.setTitle("Main Frame");
           stage.show();
           
        } else {
           lblMessage.setText("Username and Password Invalid!!!");        
        
    }
        
    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
